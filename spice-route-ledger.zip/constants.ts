
export const CURRENCY_SYMBOL = "₹";
export const TAX_RATE = 0.05; // 5% GST
export const GEMINI_MODEL_TEXT = "gemini-2.5-flash-preview-04-17";

export const DEFAULT_CATEGORIES = ["Appetizer", "Main Course", "Dessert", "Beverage", "Side Dish", "Special"];
    